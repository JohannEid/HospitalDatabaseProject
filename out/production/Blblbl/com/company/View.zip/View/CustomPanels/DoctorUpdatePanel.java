package com.company.View.CustomPanels;

import javax.swing.*;

public class DoctorUpdatePanel extends JPanel
{

}
