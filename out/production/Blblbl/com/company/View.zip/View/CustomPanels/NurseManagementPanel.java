package com.company.View.CustomPanels;

import javax.swing.*;

public class NurseManagementPanel extends JPanel
{

}
