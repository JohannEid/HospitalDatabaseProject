package com.company.Model;

public enum EShift
{
    DAY,NIGHT
}
