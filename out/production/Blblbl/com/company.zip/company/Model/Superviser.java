package com.company.Model;

public class Superviser extends Doctor
{
    public Superviser(BasicInfo basicInfo, int idNumber, String speciality)
    {
        super(basicInfo, idNumber, speciality);
    }
}
