package com.company.Model;

public class Watcher extends Nurse
{
    public Watcher(BasicInfo basicInfo, int idNumber, String service, String shift, Double salary)
    {
        super(basicInfo, idNumber, service, shift, salary);
    }
}
