package com.company.Model;

public enum  EDoctorSpeciality
{
    ORTHOPEDIST,ANESTHESIST, LUNGSPECIALIST, RADIOLOG, TRAUMATOLOG
}
