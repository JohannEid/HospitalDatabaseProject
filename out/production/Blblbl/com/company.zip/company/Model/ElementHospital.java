package com.company.Model;

public abstract class ElementHospital
{

}
