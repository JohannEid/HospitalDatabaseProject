package com.company.Model;

public enum EInsurance
{
    MNAM,LMDE,MNH,MAAF,MGEN,MMA,CNAMTS,CCVRP,MNFTC,MAS,AG2R,MGSP
}
