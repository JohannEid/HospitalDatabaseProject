package com.company.Control;

public class SQLKeyWords
{
    public static final String  WhereKeyWord  = " WHERE ";
    public static final String  DeleteKeyWord = " DELETE ";
    public static final String  FromKeyWord   = " FROM ";
    public static final String  UpdateKeyWord = " UPDATE ";
    public static final String  SetKeyWord    = " SET ";
    public static final String  InsertKeyWord = " INSERT  ";
    public static final String  IntoKeyWord   = " INTO  ";
    public static final String  ValuesKeyWord = " VALUES  ";


}
